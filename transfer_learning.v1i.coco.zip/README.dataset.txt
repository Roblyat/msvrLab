# transfer_learning > 2024-05-10 5:37pm
https://universe.roboflow.com/transferlearning-kpfzg/transfer_learning-dl0gg

Provided by a Roboflow user
License: CC BY 4.0

